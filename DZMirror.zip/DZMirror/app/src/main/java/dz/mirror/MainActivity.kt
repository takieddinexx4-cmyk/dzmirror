package dz.mirror

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : AppCompatActivity() {

    private lateinit var cgRes: ChipGroup
    private lateinit var cgFps: ChipGroup
    private lateinit var cgQ: ChipGroup
    private lateinit var swAudio: MaterialSwitch
    private lateinit var tvEst: TextView
    private lateinit var tvStatus: TextView
    private lateinit var cardLink: View
    private lateinit var btnStart: MaterialButton
    private lateinit var btnStop: MaterialButton
    private var url = ""

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, ScreenService::class.java)
                    .putExtra("code", r.resultCode)
                    .putExtra("data", data)
                    .putExtra("short", shortSide())
                    .putExtra("fps", fps())
                    .putExtra("quality", quality())
                    .putExtra("audio", swAudio.isChecked)
                ContextCompat.startForegroundService(this, i)
                setRunning(true)
            }
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { askProjection() }

    private fun shortSide() = when (cgRes.checkedChipId) {
        R.id.r720 -> 720; R.id.r2k -> 1440; R.id.r4k -> 2160; else -> 1080
    }
    private fun fps() = if (cgFps.checkedChipId == R.id.f30) 30 else 60
    private fun quality() = when (cgQ.checkedChipId) { R.id.q0 -> 0; R.id.q2 -> 2; else -> 1 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        cgRes = findViewById(R.id.cgRes); cgFps = findViewById(R.id.cgFps); cgQ = findViewById(R.id.cgQ)
        swAudio = findViewById(R.id.swAudio); tvEst = findViewById(R.id.tvEst)
        tvStatus = findViewById(R.id.tvStatus); cardLink = findViewById(R.id.cardLink)
        btnStart = findViewById(R.id.btnStart); btnStop = findViewById(R.id.btnStop)

        val upd = ChipGroup.OnCheckedStateChangeListener { _, _ -> updateEstimate() }
        cgRes.setOnCheckedStateChangeListener(upd)
        cgFps.setOnCheckedStateChangeListener(upd)
        cgQ.setOnCheckedStateChangeListener(upd)
        updateEstimate()

        btnStart.setOnClickListener {
            val need = mutableListOf<String>()
            if (swAudio.isChecked && Build.VERSION.SDK_INT >= 29 && !granted(Manifest.permission.RECORD_AUDIO))
                need += Manifest.permission.RECORD_AUDIO
            if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS))
                need += Manifest.permission.POST_NOTIFICATIONS
            if (need.isEmpty()) askProjection() else permLauncher.launch(need.toTypedArray())
        }
        btnStop.setOnClickListener {
            stopService(Intent(this, ScreenService::class.java))
            setRunning(false)
        }
        findViewById<View>(R.id.btnCopy).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("url", url))
            Toast.makeText(this, "تم نسخ الرابط ✅", Toast.LENGTH_SHORT).show()
        }
        setRunning(ScreenService.isRunning)
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun askProjection() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    private fun updateEstimate() {
        val (w, h) = ScreenService.calcSize(this, shortSide())
        val mbps = ScreenService.calcBitrate(w, h, fps(), quality()) / 1_000_000
        tvEst.text = "$w×$h  •  ${fps()} إطار/ث  •  ≈ $mbps Mbps"
    }

    private fun setRunning(on: Boolean) {
        btnStart.isEnabled = !on
        btnStop.isEnabled = on
        cardLink.visibility = if (on) View.VISIBLE else View.GONE
        if (on) {
            url = "http://${localIp()}:${ScreenService.PORT}/live.ts"
            tvStatus.text = "✅ البث يعمل\n$url"
        }
    }

    private fun localIp(): String {
        var fallback = ""
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        if (ni.name.startsWith("wlan") || ni.name.startsWith("ap")) return a.hostAddress ?: ""
                        if (fallback.isEmpty()) fallback = a.hostAddress ?: ""
                    }
                }
            }
        } catch (_: Exception) {}
        return fallback.ifEmpty { "0.0.0.0" }
    }
}
