package dz.mirror

import java.io.ByteArrayOutputStream

/** MPEG-TS muxer خفيف: فيديو H.264 (Annex B) + صوت AAC (ADTS). */
class TsMuxer {
    companion object {
        const val PMT_PID = 0x1000
        const val VIDEO_PID = 0x100
        const val AUDIO_PID = 0x101
    }

    private val cc = IntArray(0x2000)

    private fun crc32(b: ByteArray): Int {
        var crc = -1
        for (x in b) {
            crc = crc xor ((x.toInt() and 0xFF) shl 24)
            repeat(8) { crc = if (crc < 0) (crc shl 1) xor 0x04C11DB7 else crc shl 1 }
        }
        return crc
    }

    private fun section(pid: Int, body: ByteArray): ByteArray {
        val crc = crc32(body)
        val pkt = ByteArray(188) { 0xFF.toByte() }
        pkt[0] = 0x47
        pkt[1] = (0x40 or (pid shr 8)).toByte()
        pkt[2] = pid.toByte()
        pkt[3] = (0x10 or (cc[pid]++ and 0xF)).toByte()
        pkt[4] = 0
        System.arraycopy(body, 0, pkt, 5, body.size)
        pkt[5 + body.size] = (crc ushr 24).toByte()
        pkt[6 + body.size] = (crc ushr 16).toByte()
        pkt[7 + body.size] = (crc ushr 8).toByte()
        pkt[8 + body.size] = crc.toByte()
        return pkt
    }

    @Synchronized
    fun pat(): ByteArray = section(
        0, byteArrayOf(
            0x00, 0xB0.toByte(), 0x0D, 0x00, 0x01, 0xC1.toByte(), 0x00, 0x00,
            0x00, 0x01, (0xE0 or (PMT_PID shr 8)).toByte(), PMT_PID.toByte()
        )
    )

    @Synchronized
    fun pmt(hasAudio: Boolean): ByteArray {
        val s = ByteArrayOutputStream()
        val len = 5 + 4 + 5 + (if (hasAudio) 5 else 0) + 4
        s.write(0x02); s.write(0xB0 or (len shr 8)); s.write(len and 0xFF)
        s.write(0x00); s.write(0x01); s.write(0xC1); s.write(0x00); s.write(0x00)
        s.write(0xE0 or (VIDEO_PID shr 8)); s.write(VIDEO_PID and 0xFF)
        s.write(0xF0); s.write(0x00)
        s.write(0x1B); s.write(0xE0 or (VIDEO_PID shr 8)); s.write(VIDEO_PID and 0xFF); s.write(0xF0); s.write(0x00)
        if (hasAudio) {
            s.write(0x0F); s.write(0xE0 or (AUDIO_PID shr 8)); s.write(AUDIO_PID and 0xFF); s.write(0xF0); s.write(0x00)
        }
        return section(PMT_PID, s.toByteArray())
    }

    /** يغلّف إطاراً واحداً في حزم TS. pcrUs != null للفيديو فقط. */
    @Synchronized
    fun pes(pid: Int, streamId: Int, ptsUs: Long, data: ByteArray, pcrUs: Long?, key: Boolean): ByteArray {
        val pts = (ptsUs * 9 / 100) and 0x1FFFFFFFFL
        val video = pid == VIDEO_PID
        val pesLen = if (video) 0 else data.size + 8
        val hdr = ByteArray(14)
        hdr[2] = 1; hdr[3] = streamId.toByte()
        hdr[4] = (pesLen shr 8).toByte(); hdr[5] = pesLen.toByte()
        hdr[6] = 0x80.toByte(); hdr[7] = 0x80.toByte(); hdr[8] = 5
        hdr[9] = (0x21 or ((pts shr 29) and 0x0EL).toInt()).toByte()
        hdr[10] = (pts shr 22).toByte()
        hdr[11] = (0x01 or ((pts shr 14) and 0xFEL).toInt()).toByte()
        hdr[12] = (pts shr 7).toByte()
        hdr[13] = (0x01 or ((pts shl 1) and 0xFEL).toInt()).toByte()
        val pes = hdr + data

        val out = ByteArrayOutputStream(pes.size + pes.size / 180 * 4 + 376)
        var off = 0
        var first = true
        while (off < pes.size) {
            val pkt = ByteArray(188)
            pkt[0] = 0x47
            pkt[1] = ((if (first) 0x40 else 0) or (pid shr 8)).toByte()
            pkt[2] = pid.toByte()
            val remaining = pes.size - off
            val withPcr = first && pcrUs != null
            val cap = if (withPcr) 176 else 184
            var pos = 4
            var afc = 1
            if (withPcr) {
                afc = 3
                val stuff = if (remaining < cap) cap - remaining else 0
                pkt[pos++] = (7 + stuff).toByte()
                pkt[pos++] = (if (key) 0x50 else 0x10).toByte()
                val base = (pcrUs!! * 9 / 100) and 0x1FFFFFFFFL
                pkt[pos++] = (base shr 25).toByte()
                pkt[pos++] = (base shr 17).toByte()
                pkt[pos++] = (base shr 9).toByte()
                pkt[pos++] = (base shr 1).toByte()
                pkt[pos++] = (((base and 1L).toInt() shl 7) or 0x7E).toByte()
                pkt[pos++] = 0
                repeat(stuff) { pkt[pos++] = 0xFF.toByte() }
            } else if (remaining < 184) {
                afc = 3
                val stuff = 184 - remaining
                pkt[pos++] = (stuff - 1).toByte()
                if (stuff > 1) {
                    pkt[pos++] = 0
                    repeat(stuff - 2) { pkt[pos++] = 0xFF.toByte() }
                }
            }
            val n = minOf(remaining, 188 - pos)
            System.arraycopy(pes, off, pkt, pos, n)
            pkt[3] = ((afc shl 4) or (cc[pid]++ and 0xF)).toByte()
            off += n
            first = false
            out.write(pkt)
        }
        return out.toByteArray()
    }
}
